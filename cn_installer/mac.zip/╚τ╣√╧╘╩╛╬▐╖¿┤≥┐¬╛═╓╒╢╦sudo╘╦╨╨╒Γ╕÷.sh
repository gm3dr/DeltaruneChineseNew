spctl --master-disable
chmod +x "./DELTARUNE Chinese Patcher.app/Contents/MacOS/DELTARUNE Chinese Patcher"
xattr -r -d com.apple.quarantine "./DELTARUNE Chinese Patcher.app"
echo "如果还是不行请前往 系统偏好设置->隐私与安全性->允许以下来源的应用程序"
echo "将其修改为「任何来源」"
read -n 1 -s -r -p "按下任意键结束"